gentopia.agent package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   gentopia.agent.openai
   gentopia.agent.openai_memory
   gentopia.agent.react
   gentopia.agent.rewoo
   gentopia.agent.vanilla

Submodules
----------

gentopia.agent.base\_agent module
---------------------------------

.. automodule:: gentopia.agent.base_agent
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.agent.plugin\_manager module
-------------------------------------

.. automodule:: gentopia.agent.plugin_manager
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gentopia.agent
   :members:
   :undoc-members:
   :show-inheritance:
