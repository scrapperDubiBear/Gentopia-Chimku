gentopia.llm.loaders package
============================

Submodules
----------

gentopia.llm.loaders.airoboros module
-------------------------------------

.. automodule:: gentopia.llm.loaders.airoboros
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.alpaca module
----------------------------------

.. automodule:: gentopia.llm.loaders.alpaca
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.baize module
---------------------------------

.. automodule:: gentopia.llm.loaders.baize
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.bloom module
---------------------------------

.. automodule:: gentopia.llm.loaders.bloom
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.camel module
---------------------------------

.. automodule:: gentopia.llm.loaders.camel
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.falcon module
----------------------------------

.. automodule:: gentopia.llm.loaders.falcon
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.flan\_alpaca module
----------------------------------------

.. automodule:: gentopia.llm.loaders.flan_alpaca
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.guanaco module
-----------------------------------

.. automodule:: gentopia.llm.loaders.guanaco
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.kullm module
---------------------------------

.. automodule:: gentopia.llm.loaders.kullm
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.mpt module
-------------------------------

.. automodule:: gentopia.llm.loaders.mpt
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.redpajama module
-------------------------------------

.. automodule:: gentopia.llm.loaders.redpajama
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.replit module
----------------------------------

.. automodule:: gentopia.llm.loaders.replit
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.samantha\_vicuna module
--------------------------------------------

.. automodule:: gentopia.llm.loaders.samantha_vicuna
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.stablelm module
------------------------------------

.. automodule:: gentopia.llm.loaders.stablelm
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.starchat module
------------------------------------

.. automodule:: gentopia.llm.loaders.starchat
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.t5\_vicuna module
--------------------------------------

.. automodule:: gentopia.llm.loaders.t5_vicuna
   :members:
   :undoc-members:
   :show-inheritance:

gentopia.llm.loaders.vicuna module
----------------------------------

.. automodule:: gentopia.llm.loaders.vicuna
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gentopia.llm.loaders
   :members:
   :undoc-members:
   :show-inheritance:
