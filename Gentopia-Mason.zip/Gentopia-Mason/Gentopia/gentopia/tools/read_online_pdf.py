from gentopia.tools.basetool import *
from typing import AnyStr
from pathlib import Path
import requests 
import PyPDF2 as pp
import os
import traceback

class ReadOnlinePDFArgs(BaseModel):
    url: str = Field(..., description="the path to read the file")


class ReadOnlinePDF(BaseTool):
    """read file from disk"""

    name = "ReadOnlinePDF"
    description = (
        "Dowload the file from a url and reads its contents onto the console."
    )
    args_schema: Optional[Type[BaseModel]] = ReadOnlinePDFArgs

    def _run(self, url) -> AnyStr:
        if '.pdf.' not in url:
            return 'This is not a PDF link. Cannot process it.'
        try:
            response = requests.get(url)
            if response.status_code == 200:
                with open('pdf_file.pdf', 'wb') as file:
                    file.write(response.content)
        except Exception as e:
            traceback.print_exc()

            pdf_content = ''
            tokens = 0
            max_tokens = 1000
            try:
                with open('pdf_file.pdf', 'rb') as file:
                    reader_obj = pp.PdfReader(file)
                    num_pages = len(reader_obj.pages)
                    
                    for num in range(num_pages):
                        page_obj = reader_obj.pages[num]
                        text = page_obj.extract_text()
                        tokens += len(text.split())
                        if tokens <= max_tokens:
                            pdf_content += text
                        else:
                            break
            except Exception as e:
                traceback.print_exc()

            os.remove('pdf_file.pdf')
            
            return pdf_content
        '''
        read_path = (
            Path(file_path)
        )
        try:
            with read_path.open("r", encoding="utf-8") as f:
                content = f.read()
            return content
        except Exception as e:
            return "Error: " + str(e)
        '''

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError


if __name__ == "__main__":
    ans = ReadOnlinePDF()._run("hello_world.pdf")
    print(ans)